from django.urls import path
from .views import (
    CreateQuickPollView,
    SubmitVoteView,
    PollResultsView,
    ClosePollView,
)

urlpatterns = [
    path('create/', CreateQuickPollView.as_view(), name='create_quickpoll'),
    path('vote/', SubmitVoteView.as_view(), name='submit_vote'),
    path('<str:code>/results/', PollResultsView.as_view(), name='poll_results'),
    path('<str:code>/close/', ClosePollView.as_view(), name='close_poll'),
]
