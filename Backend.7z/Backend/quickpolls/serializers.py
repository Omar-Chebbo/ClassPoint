from rest_framework import serializers
from .models import QuickPoll, PollOption


class PollOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PollOption
        fields = ['id', 'text', 'vote_count']


class QuickPollSerializer(serializers.ModelSerializer):
    options = PollOptionSerializer(many=True, read_only=True)
    creator = serializers.StringRelatedField(read_only=True)

    class Meta:
        model = QuickPoll
        fields = [
            'id', 'code', 'creator', 'question_type', 'option_count',
            'is_active', 'created_at', 'closed_at', 'options'
        ]
        read_only_fields = ['code', 'created_at', 'closed_at', 'options']

    def create(self, validated_data):
        """Assign creator automatically (from request user)"""
        user = self.context['request'].user
        poll = QuickPoll.objects.create(creator=user, **validated_data)
        return poll


class VoteSerializer(serializers.Serializer):
    """Handles voting on a specific option."""
    option_id = serializers.IntegerField()

    def validate_option_id(self, value):
        if not PollOption.objects.filter(id=value).exists():
            raise serializers.ValidationError("Invalid option ID.")
        return value
