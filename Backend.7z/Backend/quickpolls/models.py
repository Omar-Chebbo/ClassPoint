from django.db import models
from django.contrib.auth import get_user_model
import random

User = get_user_model()

class QuickPoll(models.Model):
    QUESTION_TYPES = [
        ('true_false', 'True / False'),
        ('yes_no_unsure', 'Yes / No / Unsure'),
        ('custom', 'Custom'),
    ]

    code = models.CharField(max_length=6, unique=True)
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quickpolls')
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPES)
    option_count = models.IntegerField(default=2)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    closed_at = models.DateTimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        """Generate a random 4-digit code when creating a new poll."""
        if not self.code:
            self.code = self._generate_unique_code()
        super().save(*args, **kwargs)

        # Automatically create options when a new poll is created
        if not self.options.exists():
            self._create_default_options()

    def _generate_unique_code(self):
        """Generates a unique 4-digit code not used by another poll."""
        while True:
            code = str(random.randint(1000, 9999))
            if not QuickPoll.objects.filter(code=code).exists():
                return code

    def _create_default_options(self):
        """Automatically generate poll options based on the poll type."""
        options = []

        if self.question_type == 'true_false':
            options = ['True', 'False']
        elif self.question_type == 'yes_no_unsure':
            options = ['Yes', 'No', 'Unsure']
        elif self.question_type == 'custom':
            options = [f'Option {i+1}' for i in range(self.option_count)]

        for text in options:
            PollOption.objects.create(poll=self, text=text)

    def __str__(self):
        return f"Poll {self.code} ({self.get_question_type_display()})"


class PollOption(models.Model):
    poll = models.ForeignKey(QuickPoll, on_delete=models.CASCADE, related_name='options')
    text = models.CharField(max_length=100)
    vote_count = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.text} ({self.vote_count} votes)"
