from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.views import APIView
from .models import QuickPoll, PollOption
from .serializers import QuickPollSerializer, VoteSerializer, PollOptionSerializer
from django.shortcuts import get_object_or_404


class CreateQuickPollView(generics.CreateAPIView):
    """Teacher creates a new poll"""
    serializer_class = QuickPollSerializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        serializer.save(creator=self.request.user)


class SubmitVoteView(APIView):
    """Submit a vote for a poll option"""
    permission_classes = [AllowAny]  # later, can be changed to authenticated students

    def post(self, request):
        serializer = VoteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        option_id = serializer.validated_data['option_id']

        option = get_object_or_404(PollOption, id=option_id)
        if not option.poll.is_active:
            return Response({"error": "This poll is closed."}, status=status.HTTP_400_BAD_REQUEST)

        option.vote_count += 1
        option.save()

        return Response({"message": "Vote submitted successfully."}, status=status.HTTP_200_OK)


class PollResultsView(APIView):
    """Get live results for a poll using its code"""
    permission_classes = [AllowAny]

    def get(self, request, code):
        poll = get_object_or_404(QuickPoll, code=code)
        options = poll.options.all()
        serializer = PollOptionSerializer(options, many=True)
        return Response({
            "code": poll.code,
            "is_active": poll.is_active,
            "results": serializer.data
        })


class ClosePollView(APIView):
    """Teacher closes a poll"""
    permission_classes = [AllowAny]

    def post(self, request, code):
        poll = get_object_or_404(QuickPoll, code=code, creator=request.user)
        poll.is_active = False
        poll.save()
        return Response({"message": "Poll closed successfully."})

