public class LoginResponse
{
    public string Access { get; set; }
    public string Refresh { get; set; }
}