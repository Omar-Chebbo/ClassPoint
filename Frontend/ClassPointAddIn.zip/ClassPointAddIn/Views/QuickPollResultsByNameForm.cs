﻿using ClassPointAddIn.API.Service;
using Newtonsoft.Json.Linq;
using System;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassPointAddIn.Views
{
    public class QuickPollResultsByNameForm : Form
    {
        private readonly QuickPollApiClient _api = new QuickPollApiClient();
        private readonly string _pollName;

        private TableLayoutPanel _root;
        private Label _lblHeader;
        private Panel _content;
        private Button _btnRefresh;

        public QuickPollResultsByNameForm(string pollName)
        {
            _pollName = pollName;

            this.Text = "Poll Results – " + pollName;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10.5F);
            this.BackColor = Color.White;
            this.Size = new Size(900, 650);

            BuildUI();
            // Fire and forget (safe in WinForms constructor)
            Task.Run(async () => await LoadDataAsync());
        }

        private void BuildUI()
        {
            _root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(16)
            };
            _root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); // header
            _root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); // refresh
            _root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); // content
            this.Controls.Add(_root);

            _lblHeader = new Label
            {
                Text = "Results for: " + _pollName,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI Semibold", 13F, FontStyle.Bold)
            };
            _root.Controls.Add(_lblHeader, 0, 0);

            _btnRefresh = new Button
            {
                Text = "Refresh",
                Dock = DockStyle.Left,
                Width = 120
            };
            _btnRefresh.Click += async (s, e) => await LoadDataAsync();
            _root.Controls.Add(_btnRefresh, 0, 1);

            _content = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true
            };
            _root.Controls.Add(_content, 0, 2);
        }

        private async Task LoadDataAsync()
        {
            try
            {
                // Fetch data (this can run on background thread)
                string json = await _api.GetResultsByNameAsync(_pollName);
                var doc = JObject.Parse(json);

                var pollsToken = doc["polls"];
                var polls = pollsToken != null ? pollsToken.ToArray() : new JToken[0];

                // Update UI safely on the main thread
                this.Invoke((Action)(() =>
                {
                    _content.Controls.Clear();

                    int y = 10;
                    foreach (var poll in polls)
                    {
                        string code = (string)poll["poll_code"];
                        string createdAt = (string)poll["created_at"];

                        // Poll card
                        var card = new Panel
                        {
                            Left = 10,
                            Top = y,
                            Width = _content.ClientSize.Width - 40,
                            Height = 120,
                            BorderStyle = BorderStyle.FixedSingle,
                            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
                        };
                        _content.Controls.Add(card);
                        y += card.Height + 10;

                        var lblTitle = new Label
                        {
                            Text = "Poll Code: " + code + "   •   Created: " + createdAt,
                            Dock = DockStyle.Top,
                            Height = 28,
                            Font = new Font("Segoe UI Semibold", 10.5F, FontStyle.Bold)
                        };
                        card.Controls.Add(lblTitle);

                        var list = new ListView
                        {
                            Dock = DockStyle.Fill,
                            View = View.Details,
                            FullRowSelect = true
                        };
                        list.Columns.Add("Option", 240);
                        list.Columns.Add("Votes", 80);
                        list.Columns.Add("Voters (names)", 520);
                        card.Controls.Add(list);

                        var results = poll["results"];
                        if (results != null)
                        {
                            foreach (var r in results)
                            {
                                string optionText = (string)r["option"];
                                int count = (int)r["vote_count"];
                                string voters = string.Join(", ", r["voters"].Select(v => (string)v));

                                var item = new ListViewItem(optionText);
                                item.SubItems.Add(count.ToString());
                                item.SubItems.Add(voters);
                                list.Items.Add(item);
                            }
                        }
                    }

                    if (polls.Length == 0)
                    {
                        var empty = new Label
                        {
                            Text = "No polls found with this name.",
                            Dock = DockStyle.Top,
                            ForeColor = Color.DimGray
                        };
                        _content.Controls.Add(empty);
                    }
                }));
            }
            catch (Exception ex)
            {
                // Also marshal exception message safely
                this.Invoke((Action)(() =>
                {
                    _content.Controls.Clear();
                    var err = new Label
                    {
                        Text = "Error: " + ex.Message,
                        Dock = DockStyle.Top,
                        ForeColor = Color.Red
                    };
                    _content.Controls.Add(err);
                }));
            }
        }

    }
}
